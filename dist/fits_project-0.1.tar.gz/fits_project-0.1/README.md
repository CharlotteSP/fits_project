# fits_project
Small introductory package for how to handle .fits files for codeastro course. 
